"use client";
import React from "react";

function MainComponent() {
  const [url, setUrl] = useState("");
  const [transcript, setTranscript] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copySuccess, setCopySuccess] = useState(false);
  const [targetLang, setTargetLang] = useState("en");
  const [translation, setTranslation] = useState("");
  const [detectedLanguage, setDetectedLanguage] = useState("");
  const [translating, setTranslating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [streamStatus, setStreamStatus] = useState("");
  const [processingMessage, setProcessingMessage] = useState("");
  const [partialTranscript, setPartialTranscript] = useState("");
  const [history, setHistory] = useState([]);
  const [videoTitle, setVideoTitle] = useState("");

  const extractVideoId = (url) => {
    let match = url.match(
      /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/
    );
    return match ? match[1] : null;
  };

  const updateProgress = (status, message, progressValue) => {
    setStreamStatus(status);
    setProcessingMessage(message);
    setProgress(progressValue);
  };

  const loadHistoryItem = (item) => {
    setUrl(item.url);
    setTranscript(item.transcript);
    setDetectedLanguage(item.detectedLanguage);
    setVideoTitle(item.videoTitle);
  };

  const downloadTranscript = () => {
    const element = document.createElement("a");
    const file = new Blob([transcript], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `transcript-${videoTitle || "youtube"}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const shareTranscript = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: videoTitle || "YouTube Transcript",
          text: transcript,
        });
      } catch (err) {
        console.error("Error sharing:", err);
      }
    } else {
      copyToClipboard();
    }
  };

  const fetchTranscript = async () => {
    setLoading(true);
    setError("");
    setTranscript("");
    setDetectedLanguage("");
    setPartialTranscript("");
    setVideoTitle("");

    const videoId = extractVideoId(url);
    if (!videoId) {
      setError("Please enter a valid YouTube URL (regular video or Shorts)");
      setLoading(false);
      return;
    }

    try {
      updateProgress("Connecting to video...", "Initializing connection", 10);
      await new Promise((r) => setTimeout(r, 500));

      updateProgress("Extracting speech...", "Processing audio stream", 30);
      const response = await fetch("/api/extract-audio-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch transcript");
      }

      updateProgress("Processing transcript...", "Analyzing content", 60);
      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      updateProgress("Finalizing...", "Almost done", 90);

      const lines = data.transcript.split("\n");
      for (let i = 0; i < lines.length; i++) {
        setPartialTranscript(lines.slice(0, i + 1).join("\n"));
        await new Promise((r) => setTimeout(r, 100));
      }

      setTranscript(data.transcript);
      setDetectedLanguage(data.detectedLanguage);
      setVideoTitle(data.videoTitle);
      updateProgress("Complete!", "Transcript ready", 100);

      setHistory((prev) => [
        {
          url,
          videoId,
          transcript: data.transcript,
          detectedLanguage: data.detectedLanguage,
          videoTitle: data.videoTitle,
          date: new Date().toISOString(),
        },
        ...prev.slice(0, 9),
      ]);

      await new Promise((r) => setTimeout(r, 500));
    } catch (err) {
      setError(err.message || "Failed to process video");
      console.error(err);
    } finally {
      setLoading(false);
      setProgress(0);
      setStreamStatus("");
      setProcessingMessage("");
    }
  };

  const handleTranslate = async () => {
    if (!transcript || translating) return;

    setTranslating(true);
    try {
      const response = await fetch(
        "/integrations/google-translate/language/translate/v2",
        {
          method: "POST",
          body: new URLSearchParams({
            q: transcript,
            target: targetLang,
            source: detectedLanguage,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Translation failed");
      }

      const data = await response.json();
      setTranslation(data.data.translations[0].translatedText);
    } catch (err) {
      setError("Translation failed. Please try again.");
      console.error(err);
    } finally {
      setTranslating(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(transcript);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      setError(
        "Unable to copy text - please try selecting and copying manually"
      );
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-white py-12 px-4 md:px-8 border-b">
        <div className="max-w-5xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-3 text-gray-900 font-roboto">
            YouTube Speech Extractor
          </h1>
          <h2 className="text-lg md:text-xl text-gray-600 font-inter">
            Convert any YouTube video or Short into text
          </h2>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8">
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Paste YouTube video or Shorts URL here..."
            className="w-full px-6 py-4 text-lg border border-gray-200 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-colors font-inter mb-4"
            name="youtube-url"
          />
          <button
            onClick={fetchTranscript}
            disabled={loading}
            className="w-full py-4 bg-orange-500 text-white rounded-lg hover:bg-orange-600 disabled:bg-orange-300 transition-colors font-inter text-lg font-medium"
          >
            {loading ? (
              <span className="flex items-center justify-center">
                <div className="w-5 h-5 border-t-2 border-b-2 border-white rounded-full animate-spin mr-3"></div>
                Extracting...
              </span>
            ) : (
              "Extract"
            )}
          </button>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-100 text-red-600 rounded-lg font-inter text-sm">
            {error}
          </div>
        )}

        {(loading || transcript) && (
          <div className="bg-white rounded-lg shadow-sm border mb-8">
            <div className="grid md:grid-cols-2 gap-6 p-6">
              <div className="space-y-4">
                <div className="aspect-video bg-gray-50 rounded-lg overflow-hidden">
                  <iframe
                    src={`https://www.youtube.com/embed/${extractVideoId(url)}`}
                    className="w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="space-y-3">
                  {detectedLanguage && (
                    <div className="text-sm text-gray-500 font-inter">
                      Original language: {detectedLanguage}
                    </div>
                  )}
                  <div className="flex flex-wrap gap-3">
                    <select
                      value={targetLang}
                      onChange={(e) => setTargetLang(e.target.value)}
                      className="flex-1 px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-orange-500 font-inter"
                    >
                      <option value="en">English</option>
                      <option value="es">Spanish</option>
                      <option value="zh">Mandarin Chinese</option>
                      <option value="hi">Hindi</option>
                      <option value="ar">Arabic</option>
                      <option value="bn">Bengali</option>
                      <option value="pt">Portuguese</option>
                      <option value="ru">Russian</option>
                      <option value="ja">Japanese</option>
                      <option value="de">German</option>
                    </select>
                    <div className="flex gap-2">
                      <button
                        onClick={copyToClipboard}
                        className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-inter text-sm"
                        title="Copy to clipboard"
                      >
                        <i className="fas fa-copy"></i>
                      </button>
                      <button
                        onClick={downloadTranscript}
                        className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-inter text-sm"
                        title="Download as text"
                      >
                        <i className="fas fa-download"></i>
                      </button>
                      <button
                        onClick={shareTranscript}
                        className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-inter text-sm"
                        title="Share transcript"
                      >
                        <i className="fas fa-share-alt"></i>
                      </button>
                      <button
                        onClick={handleTranslate}
                        disabled={translating}
                        className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 disabled:bg-orange-300 transition-colors font-inter text-sm"
                      >
                        <i className="fas fa-language mr-2"></i>
                        {translating ? "Translating..." : "Translate"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              {loading ? (
                <div className="h-[500px] p-4 bg-gray-50 rounded-lg font-inter">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-5 h-5 border-t-2 border-b-2 border-orange-500 rounded-full animate-spin"></div>
                      <div className="text-gray-600">{streamStatus}</div>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-orange-500 transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {processingMessage}
                    </div>
                  </div>
                  {partialTranscript && (
                    <div className="mt-8 space-y-3 animate-fade-in">
                      {partialTranscript.split("\n").map((line, i) => (
                        <p key={i} className="text-gray-600 text-sm">
                          {line}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-[500px] overflow-y-auto p-4 bg-gray-50 rounded-lg font-inter text-gray-700 leading-relaxed text-sm">
                  {transcript.split("\n").map((paragraph, index) => (
                    <p
                      key={index}
                      className="mb-3 p-2 rounded hover:bg-white transition-colors"
                    >
                      {paragraph}
                    </p>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold text-gray-800 font-inter">
              Recent Transcripts
            </h3>
            <button
              onClick={() => setHistory([])}
              className="text-sm text-gray-500 hover:text-red-500 transition-colors"
            >
              <i className="fas fa-trash-alt mr-2"></i>
              Clear History
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {history.map((item, index) => (
              <div
                key={index}
                onClick={() => loadHistoryItem(item)}
                className="cursor-pointer group border rounded-lg overflow-hidden hover:shadow-md transition-all"
              >
                <div className="aspect-video bg-gray-100">
                  <img
                    src={`https://img.youtube.com/vi/${item.videoId}/mqdefault.jpg`}
                    alt={item.videoTitle}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3">
                  <h4 className="font-medium text-gray-800 truncate">
                    {item.videoTitle}
                  </h4>
                  <p className="text-sm text-gray-500 mt-1">
                    <i className="fas fa-language mr-2"></i>
                    {item.detectedLanguage}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    <i className="fas fa-clock mr-2"></i>
                    {new Date(item.date).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-in;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;