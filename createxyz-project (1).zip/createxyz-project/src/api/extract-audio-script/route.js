async function handler({ url, targetLanguage }) {
  if (!url) {
    return { error: "Please provide a YouTube URL" };
  }

  const extractVideoId = (url) => {
    const match = url.match(
      /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/
    );
    return match ? match[1] : null;
  };

  const videoId = extractVideoId(url);
  if (!videoId) {
    return { error: "Invalid YouTube URL" };
  }

  try {
    const [transcriptResponse, videoDataResponse] = await Promise.all([
      fetch("/integrations/web-scraping/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: `https://www.youtube.com/watch?v=${videoId}`,
          getText: true,
        }),
      }),
      fetch("/integrations/web-scraping/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: `https://www.youtube.com/watch?v=${videoId}`,
          getMetadata: true,
        }),
      }),
    ]);

    if (!transcriptResponse.ok) {
      throw new Error("Failed to fetch transcript");
    }

    const [transcriptText, videoData] = await Promise.all([
      transcriptResponse.text(),
      videoDataResponse.json(),
    ]);

    if (
      transcriptText.includes("No transcript available") ||
      transcriptText.trim() === ""
    ) {
      throw new Error("No transcript available for this video");
    }

    const languageResponse = await fetch(
      "/integrations/google-translate/language/translate/v2/detect",
      {
        method: "POST",
        body: new URLSearchParams({
          q: transcriptText.slice(0, 100),
        }),
      }
    );

    const languageData = await languageResponse.json();
    const detectedLanguage = languageData.data.detections[0][0].language;

    const dbResult = await sql`
      INSERT INTO transcript_history 
      (video_id, video_url, detected_language, transcript_text, video_title) 
      VALUES 
      (${videoId}, ${url}, ${detectedLanguage}, ${transcriptText}, ${videoData.title})
      RETURNING id`;

    return {
      id: dbResult[0].id,
      transcript: transcriptText,
      detectedLanguage,
      videoId,
      videoTitle: videoData.title,
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      error: error.message || "Failed to process video",
    };
  }
}